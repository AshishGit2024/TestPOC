# GitHub API configurations
GITHUB_TOKEN = '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'
GITHUB_USERNAME = 'gurukiran2805'
GITHUB_API_URL = "https://api.github.com"
