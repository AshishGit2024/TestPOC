import requests
import config
from response import generate_response, error_response, elicit_slot_response
from check_repo import check_repo_exists

def validate_delete_repo(slots):
    if not slots['RepoName']:
        return {
            'isValid': False,
            'violatedSlot': 'RepoName'
        }
    return {'isValid': True}

def delete_repo_handler(event):
    slots = event['sessionState']['intent']['slots']
    intent_name = event['sessionState']['intent']['name']
    
    if event['invocationSource'] == 'DialogCodeHook':
        validation_result = validate_delete_repo(slots)
        
        if not validation_result['isValid']:
            return elicit_slot_response(intent_name, slots, validation_result['violatedSlot'], validation_result)
        
        return {
            "sessionState": {
                "dialogAction": {
                    "type": "Delegate"
                },
                "intent": {
                    'name': intent_name,
                    'slots': slots
                }
            }
        }
    
    if event['invocationSource'] == 'FulfillmentCodeHook':
        repo_name = slots['RepoName']['value']['originalValue']
        
        try:
            repo_exists, repo_url = check_repo_exists(repo_name)

            if not repo_exists:
                return generate_response(
                    intent_name,
                    slots,
                    f"❌ The repository **{repo_name}** does not exist.",
                    state='Fulfilled'
                )

            delete_url = f"{config.GITHUB_API_URL}/repos/{config.GITHUB_USERNAME}/{repo_name}"
            headers = {
                "Authorization": f"token {config.GITHUB_TOKEN}"
            }
            response = requests.delete(delete_url, headers=headers)

            if response.status_code == 204:
                return generate_response(
                    intent_name,
                    slots,
                    f"🎉 The repository **{repo_name}** has been deleted successfully.",
                    state='Fulfilled'
                )
            else:
                raise Exception(f"Failed to delete repo: {response.json().get('message', 'Unknown error')}")
        except Exception as e:
            return error_response(
                intent_name,
                slots,
                f"❌ **Repository Deletion Failed**\n\n"
                f"Sorry, there was an issue while deleting the repository: {str(e)}. Please try again later."
            )
