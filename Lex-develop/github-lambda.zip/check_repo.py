
import requests
import config

def check_repo_exists(repo_name):
    
    try:
        url = f"{config.GITHUB_API_URL}/repos/{config.GITHUB_USERNAME}/{repo_name}"
        headers = {
            "Authorization": f"token {config.GITHUB_TOKEN}"
        }

        response = requests.get(url, headers=headers)

        if response.status_code == 200:
            repo_data = response.json()
            repo_url = repo_data.get("html_url")
            return True, repo_url  
        elif response.status_code == 404:
            return False, None  
        else:
            raise Exception(f"Error checking repository: {response.json().get('message', 'Unknown error')}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"RequestException while checking repo {repo_name}: {str(e)}")
    except Exception as e:
        raise Exception(f"Error checking repo {repo_name}: {str(e)}")
