import requests
import base64
import config
from response import generate_response, error_response, elicit_slot_response
from check_repo import check_repo_exists  

def validate_create_repo(slots):
    if not slots['RepoName']:
        return {
            'isValid': False,
            'violatedSlot': 'RepoName'
        }
    return {'isValid': True}

def create_repo_handler(event):
    
    slots = event['sessionState']['intent']['slots']
    intent_name = event['sessionState']['intent']['name']
    
    if event['invocationSource'] == 'DialogCodeHook':
        validation_result = validate_create_repo(slots)
        
        if not validation_result['isValid']:
            return elicit_slot_response(intent_name, slots, validation_result['violatedSlot'], validation_result)
        
        return {
            "sessionState": {
                "dialogAction": {
                    "type": "Delegate"
                },
                "intent": {
                    'name': intent_name,
                    'slots': slots
                }
            }
        }
    
    if event['invocationSource'] == 'FulfillmentCodeHook':
        repo_name = slots['RepoName']['value']['originalValue']
        description = slots.get('description', {}).get('value', "")
        
        try:
            repo_exists, repo_url = check_repo_exists(repo_name)

            if repo_exists:
                return generate_response(
                    intent_name,
                    slots,
                    f"The repository **{repo_name}** already exists. You can access it here: {repo_url}",
                    state='Fulfilled'
                )

            url = f"{config.GITHUB_API_URL}/user/repos"
            data = {
                "name": repo_name,
                "description": description,
                "private": False  
            }
            headers = {
                "Authorization": f"token {config.GITHUB_TOKEN}"
            }
            response = requests.post(url, json=data, headers=headers)

            if response.status_code == 201:
                repo_data = response.json()
                repo_url = repo_data.get("html_url")

                readme_content = """
# Repository Created from DevOpOsne Agent

This repository was created from the chat agent. Feel free to add your content here.
"""
                encoded_content = base64.b64encode(readme_content.encode()).decode()

                create_file_url = f"{config.GITHUB_API_URL}/repos/{config.GITHUB_USERNAME}/{repo_name}/contents/README.md"
                file_data = {
                    "message": "Initial commit with README.md",
                    "content": encoded_content,
                    "branch": "main"
                }
                file_response = requests.put(create_file_url, json=file_data, headers=headers)

                if file_response.status_code != 201:
                    raise Exception(f"Failed to create README.md file: {file_response.json().get('message', 'Unknown error')}")

                jenkinsfile_content = """
pipeline {
    agent any

    stages {
        stage('Build') {
            steps {
                echo 'Building...'
            }
        }

        stage('Test') {
            steps {
                echo 'Testing...'
            }
        }

        stage('Deploy') {
            steps {
                echo 'Deploying...'
            }
        }
    }
}
"""
                encoded_jenkinsfile_content = base64.b64encode(jenkinsfile_content.encode()).decode()

                create_jenkinsfile_url = f"{config.GITHUB_API_URL}/repos/{config.GITHUB_USERNAME}/{repo_name}/contents/Jenkinsfile"
                jenkinsfile_data = {
                    "message": "Add Jenkinsfile for pipeline",
                    "content": encoded_jenkinsfile_content,
                    "branch": "main"
                }
                jenkinsfile_response = requests.put(create_jenkinsfile_url, json=jenkinsfile_data, headers=headers)

                if jenkinsfile_response.status_code == 201:
                    # Return the URL of the created repository
                    message = (
                        f"The repository **{repo_name}** has been created.\n\n"
                        f"📂 You can access it here: {repo_url}\n\n"
                        f"Would you like to create another repository or perform another action?"
                    )
                    
                    return generate_response(
                        intent_name,
                        slots,
                        message,
                        state='Fulfilled'
                    )
                else:
                    raise Exception(f"Failed to create Jenkinsfile: {jenkinsfile_response.json().get('message', 'Unknown error')}")
            else:
                raise Exception(f"Failed to create repo: {response.json().get('message', 'Unknown error')}")
        except ValueError as e:
            return error_response(
                intent_name,
                slots,
                f"❌ **Invalid Repository Name**\n\n"
                f"Error: {str(e)}. Please provide a valid repository name and try again."
            )
        except Exception as e:
            return error_response(
                intent_name,
                slots,
                f"❌ **Repository Creation Failed**\n\n"
                f"Sorry, there was an issue while creating the repository: {str(e)}. Please try again later."
            )
