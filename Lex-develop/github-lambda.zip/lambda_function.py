import json
from list_repo_handler import list_repo_handler
from create_repo_handler import create_repo_handler
from check_repo import check_repo_exists
from delete_repo_handler import delete_repo_handler
from response import generate_response
from greet_github_handler import greet_github_handler


def lambda_handler(event, context):
    try:
        intent_name = event['sessionState']['intent']['name']
        slots = event['sessionState']['intent']['slots']
        
        if intent_name == "ListReposIntent":
            return list_repo_handler(event)
        elif intent_name == "GreetIntent":
            return greet_github_handler(event)
        elif intent_name == "CreateRepoIntent":
            return create_repo_handler(event)
        elif intent_name == "DeleteRepoIntent":
            return delete_repo_handler(event)
    
    except Exception as e:
        # Handle other unexpected errors
        print(f"Unexpected error: {str(e)}")
        return generate_response(intent_name,slots, f"Sorry about that, something went wrong. Let me try that again!", state="Failed")
