import requests
import config
from response import generate_response

def list_repo_handler(event):
    slots = event['sessionState']['intent']['slots']
    intent = event['sessionState']['intent']['name']
    
    try:
        url = f"{config.GITHUB_API_URL}/user/repos"
        headers = {
            "Authorization": f"token {config.GITHUB_TOKEN}"
        }

        response = requests.get(url, headers=headers)

        if response.status_code == 200:
            repos = response.json()
            if not repos:
                return "You have no repositories."
            else:
                repo_list = [repo['clone_url'] for repo in repos]
                repos_message= f"Your repositories: {'  '.join(repo_list)}"
                return generate_response(intent,slots, repos_message, state='Fulfilled')
                
        else:
            raise Exception(f"Failed to list repositories: {response.json().get('message', 'Unknown error')}")

    except requests.exceptions.RequestException as e:
        raise Exception(f"RequestException while listing repos: {str(e)}")

    except Exception as e:
        raise Exception(f"Error while listing repos: {str(e)}")
