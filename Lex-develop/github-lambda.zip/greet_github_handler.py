import random

def greet_github_handler(event):
    intent_name = event['sessionState']['intent']['name']

    greetings = [
        "Hello! I'm GitHubBot. How can I assist you today? Please select an option below or type what you're looking for.",
        "Hi there! GitHubBot here. How can I help you today? You can either choose an option or tell me what you need.",
        "Hello! GitHubBot at your service. How can I assist you today? Select an option or type your request.",
        "Hi! I'm GitHubBot. Ready to help you with your GitHub repositories. Pick an option below or feel free to type your query.",
        "Hey there! GitHubBot here. What can I assist you with today? You can either choose an option or describe what you're looking for.",
        "Hello! GitHubBot here. How can I assist you today? Choose one of the options below, or type your request and I’ll help you out."
    ]

    selected_greeting = random.choice(greetings)

    plain_text_message = (
        "You can either choose one of the options or type what you're looking for, "
        "such as 'create a repository', 'delete a repository', or 'list my repositories'. "
        "I'll take care of the rest!"
    )

    response = {
        "sessionState": {
            "dialogAction": {
                "type": "ElicitIntent",  
                "message": {
                    "contentType": "PlainText",
                    "content": selected_greeting
                }
            },
            "intent": {
                "name": "GreetIntent",
                "state": "Fulfilled"
            }
        },
        "messages": [
            {
                "contentType": "ImageResponseCard",
                "content": " ",
                "imageResponseCard": {
                    "title": selected_greeting,
                    "subtitle": " ",
                    "buttons": [
                        {
                            "text": "Create Repository",
                            "value":"create a repository"
                        },
                        {
                            "text": "Delete Repository",
                            "value": "delete a repository"
                        },
                        {
                            "text": "list my repositories",
                            "value": "list my repositories"
                        }
                    ]
                }
              },
              {
                  "contentType": "PlainText",
                   "content": plain_text_message
            }
              

        ]
    }

    return response